import { createBrowserRouter } from "react-router";
import Home from "./pages/Home";
import PaymentPage from "./pages/PaymentPage";
import RoulettePage from "./pages/RoulettePage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/payment/:boxType",
    Component: PaymentPage,
  },
  {
    path: "/roulette/:boxType",
    Component: RoulettePage,
  },
]);
