// Serviço de integração com ProPay API
const BASE_URL = 'https://api-connectmdcpay.squareweb.app';

// IMPORTANTE: Em produção, use variáveis de ambiente para armazenar suas credenciais
// Nunca exponha suas chaves de API diretamente no código frontend
const API_KEY = 'SUA_API_KEY_AQUI'; // Substitua pela sua API Key do ProPay

export interface CreateChargeParams {
  amount: number; // Valor em reais (ex: 15.00)
  description: string;
  customer?: {
    name?: string;
    email?: string;
    cpf?: string;
  };
}

export interface ChargeResponse {
  id: string;
  status: 'pending' | 'paid' | 'expired' | 'cancelled';
  pixCode: string; // Código PIX copia e cola
  qrCodeUrl?: string; // URL da imagem do QR Code
  expiresAt: string;
  amount: number;
}

export interface PaymentStatus {
  id: string;
  status: 'pending' | 'paid' | 'expired' | 'cancelled';
  paidAt?: string;
}

// Cria uma nova cobrança PIX
export async function createPixCharge(params: CreateChargeParams): Promise<ChargeResponse> {
  try {
    const response = await fetch(`${BASE_URL}/charges`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`,
      },
      body: JSON.stringify({
        amount: params.amount,
        description: params.description,
        paymentMethod: 'pix',
        customer: params.customer,
      }),
    });

    if (!response.ok) {
      throw new Error('Erro ao criar cobrança PIX');
    }

    return await response.json();
  } catch (error) {
    console.error('Erro ao criar cobrança:', error);
    throw error;
  }
}

// Verifica o status de um pagamento
export async function checkPaymentStatus(chargeId: string): Promise<PaymentStatus> {
  try {
    const response = await fetch(`${BASE_URL}/charges/${chargeId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
      },
    });

    if (!response.ok) {
      throw new Error('Erro ao verificar status do pagamento');
    }

    return await response.json();
  } catch (error) {
    console.error('Erro ao verificar pagamento:', error);
    throw error;
  }
}

// Polling: Verifica o pagamento a cada X segundos até ser confirmado
export async function waitForPayment(
  chargeId: string,
  onStatusChange: (status: PaymentStatus) => void,
  intervalMs: number = 3000 // Verifica a cada 3 segundos
): Promise<void> {
  return new Promise((resolve, reject) => {
    const interval = setInterval(async () => {
      try {
        const status = await checkPaymentStatus(chargeId);
        onStatusChange(status);

        if (status.status === 'paid') {
          clearInterval(interval);
          resolve();
        } else if (status.status === 'expired' || status.status === 'cancelled') {
          clearInterval(interval);
          reject(new Error('Pagamento expirado ou cancelado'));
        }
      } catch (error) {
        clearInterval(interval);
        reject(error);
      }
    }, intervalMs);

    // Timeout de 15 minutos
    setTimeout(() => {
      clearInterval(interval);
      reject(new Error('Timeout: Pagamento não confirmado'));
    }, 15 * 60 * 1000);
  });
}
