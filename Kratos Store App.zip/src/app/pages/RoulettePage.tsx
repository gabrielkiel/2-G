import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router';
import confetti from 'canvas-confetti';
import { ArrowLeft, Sparkles, Lock } from 'lucide-react';

export default function RoulettePage() {
  const { boxType } = useParams();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [winner, setWinner] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);

  // Verificação de pagamento
  const isVerified = searchParams.get('verified') === 'true';
  const paymentId = searchParams.get('paymentId');

  useEffect(() => {
    // Bloqueia acesso se não tiver confirmação de pagamento
    if (!isVerified && !paymentId) {
      navigate(`/payment/${boxType}`);
    }
  }, [isVerified, paymentId, boxType, navigate]);

  // Se não estiver verificado, mostra tela de bloqueio
  if (!isVerified && !paymentId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white flex items-center justify-center p-4">
        <div className="text-center">
          <Lock size={64} className="mx-auto mb-4 text-red-500" />
          <h1 className="text-3xl font-bold mb-2">Acesso Bloqueado</h1>
          <p className="text-gray-400 mb-6">Você precisa realizar o pagamento primeiro</p>
          <button
            onClick={() => navigate(`/payment/${boxType}`)}
            className="px-8 py-3 bg-gradient-to-r from-red-500 to-orange-500 rounded-xl font-bold hover:brightness-125 transition-all"
          >
            Fazer Pagamento
          </button>
        </div>
      </div>
    );
  }

  // Definição dos prêmios para cada caixa
  const prizes: Record<string, string[]> = {
    '1': [
      "50 dimas",
      "100 dimas",
      "sensi",
      "codiguinho",
      "50 dimas",
      "passe booyah 🔥",
      "100 dimas",
      "50 dimas",
      "sensi",
      "200 dimas (Raro)"
    ],
    '2': [
      "100 dimas", "200 dimas", "sensi premium", "100 dimas", "codiguinho",
      "100 dimas", "200 dimas", "100 dimas", "sensi premium", "310 dimas 🔵",
      "100 dimas", "200 dimas", "codiguinho", "100 dimas", "sensi premium",
      "100 dimas", "200 dimas", "100 dimas", "codiguinho", "520 dimas 🟣",
      "100 dimas", "200 dimas", "sensi premium", "100 dimas", "codiguinho",
      "100 dimas", "200 dimas", "100 dimas", "Passe Booyah 🔥", "1040 dimas 🟡"
    ],
    '3': [
      "310 dimas", "520 dimas", "sensi premium", "310 dimas", "codiguinho top",
      "310 dimas", "520 dimas", "310 dimas", "sensi premium", "1040 dimas 🔵",
      "310 dimas", "520 dimas", "codiguinho top", "310 dimas", "sensi premium",
      "310 dimas", "520 dimas", "310 dimas", "codiguinho top", "1560 dimas 🟣",
      "310 dimas", "520 dimas", "sensi premium", "310 dimas", "codiguinho top",
      "310 dimas", "520 dimas", "310 dimas", "Passe Booyah + bônus 🔥", "2120 dimas 🟡"
    ]
  };

  const currentPrizes = prizes[boxType || '1'];
  const numberOfPrizes = currentPrizes.length;

  // Cores alternadas para os segmentos
  const getSegmentColor = (index: number) => {
    // Roleta toda preta
    return 'from-black to-gray-900';
  };

  const spinRoulette = () => {
    if (spinning) return;

    setSpinning(true);
    setWinner(null);
    setShowResult(false);

    // Sorteia um prêmio
    const winnerIndex = Math.floor(Math.random() * numberOfPrizes);
    const winnerPrize = currentPrizes[winnerIndex];

    // Calcula rotação final (múltiplas voltas + posição do prêmio)
    const segmentAngle = 360 / numberOfPrizes;
    const extraSpins = 5; // Número de voltas completas
    const targetRotation = (extraSpins * 360) + (360 - (winnerIndex * segmentAngle) - (segmentAngle / 2));

    setRotation(targetRotation);

    // Após a animação
    setTimeout(() => {
      setWinner(winnerPrize);
      setSpinning(false);
      setShowResult(true);
      
      // Confetti para prêmios raros
      if (winnerPrize.includes('Raro') || winnerPrize.includes('🔵') || winnerPrize.includes('🟣') || winnerPrize.includes('🟡') || winnerPrize.includes('🔥')) {
        confetti({
          particleCount: 200,
          spread: 100,
          origin: { y: 0.6 }
        });
      }

      // Notificação (em produção seria webhook para você)
      console.log('🎉 ALGUÉM GANHOU!', {
        premio: winnerPrize,
        caixa: boxType,
        timestamp: new Date().toISOString()
      });

      // Aqui você integraria com Telegram Bot ou API para receber notificação real
      // sendTelegramNotification({ prize: winnerPrize, box: boxType });
    }, 4000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white flex flex-col items-center justify-center p-4">
      {/* Back Button */}
      <button
        onClick={() => navigate('/')}
        className="absolute top-6 left-6 flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
      >
        <ArrowLeft size={20} />
        <span>Voltar</span>
      </button>

      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-black mb-2 bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 bg-clip-text text-transparent">
          🎰 ROLETA DA SORTE
        </h1>
        <p className="text-gray-400">Gire a roleta e descubra seu prêmio!</p>
      </div>

      {/* Roulette Container */}
      <div className="relative mb-8" ref={canvasRef}>
        {/* Seta indicadora */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-4 z-20">
          <div className="w-0 h-0 border-l-[20px] border-l-transparent border-r-[20px] border-r-transparent border-t-[40px] border-t-red-500 drop-shadow-[0_0_10px_rgba(255,0,0,0.8)]" />
        </div>

        {/* Roulette Wheel */}
        <div className="relative w-[400px] h-[400px] rounded-full overflow-hidden shadow-[0_0_60px_rgba(138,43,226,0.8)]">
          <div
            className="w-full h-full relative"
            style={{
              transform: `rotate(${rotation}deg)`,
              transition: spinning ? 'transform 4s cubic-bezier(0.17, 0.67, 0.12, 0.99)' : 'none',
            }}
          >
            {currentPrizes.map((prize, index) => {
              const segmentAngle = 360 / numberOfPrizes;
              const startAngle = index * segmentAngle;

              return (
                <div
                  key={index}
                  className={`absolute w-full h-full bg-gradient-to-br ${getSegmentColor(index)} border-r border-gray-700`}
                  style={{
                    clipPath: `polygon(50% 50%, ${50 + 50 * Math.cos((startAngle - 90) * Math.PI / 180)}% ${50 + 50 * Math.sin((startAngle - 90) * Math.PI / 180)}%, ${50 + 50 * Math.cos((startAngle + segmentAngle - 90) * Math.PI / 180)}% ${50 + 50 * Math.sin((startAngle + segmentAngle - 90) * Math.PI / 180)}%)`,
                  }}
                >
                  <div
                    className="absolute inset-0 flex items-center justify-center"
                    style={{
                      transform: `rotate(${startAngle + segmentAngle / 2}deg)`,
                      transformOrigin: 'center',
                    }}
                  >
                    <span
                      className="text-4xl"
                      style={{
                        transform: 'translateY(-120px)',
                      }}
                    >
                      🎁
                    </span>
                  </div>
                </div>
              );
            })}

            {/* Center Circle */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full shadow-xl flex items-center justify-center border-4 border-white">
              <Sparkles className="text-white" size={32} />
            </div>
          </div>
        </div>
      </div>

      {/* Spin Button */}
      {!showResult && (
        <button
          onClick={spinRoulette}
          disabled={spinning}
          className={`px-12 py-4 rounded-full font-black text-xl shadow-2xl transition-all duration-300 ${
            spinning
              ? 'bg-gray-600 cursor-not-allowed'
              : 'bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 hover:scale-110 hover:shadow-[0_0_40px_rgba(147,51,234,0.8)]'
          }`}
        >
          {spinning ? '🎰 GIRANDO...' : '🎯 GIRAR ROLETA'}
        </button>
      )}

      {/* Result */}
      {showResult && winner && (
        <div className="mt-8 text-center animate-bounce">
          <div className="bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 p-[3px] rounded-3xl shadow-[0_0_50px_rgba(255,215,0,0.8)]">
            <div className="bg-gray-900 rounded-3xl p-8">
              <h2 className="text-3xl font-black mb-4">🎉 PARABÉNS!</h2>
              <p className="text-xl mb-6">Você ganhou:</p>
              <div className="text-4xl font-black bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent mb-6">
                {winner}
              </div>

              {/* WhatsApp Contact */}
              <div className="bg-gray-800 rounded-2xl p-6 mb-4">
                <p className="text-sm text-gray-300 mb-3">
                  📱 Entre em contato para resgatar seu prêmio:
                </p>
                <a
                  href="https://wa.me/5551995588124?text=Olá! Ganhei um prêmio na roleta Kratos Store!"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 rounded-xl font-bold transition-colors"
                >
                  <span>📞 WhatsApp Kratos Store</span>
                </a>
                <p className="text-xs text-gray-500 mt-2">
                  (51) 99558-8124
                </p>
              </div>

              <button
                onClick={() => navigate('/')}
                className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl font-bold hover:brightness-125 transition-all"
              >
                🏠 Voltar para a loja
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Prize List */}
      <div className="mt-12 max-w-2xl">
        <h3 className="text-center font-bold mb-4 text-gray-400">📋 Prêmios disponíveis nesta caixa:</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {currentPrizes.map((prize, idx) => (
            <div key={idx} className="bg-gray-800/50 rounded-lg px-3 py-2 text-sm text-center text-gray-300">
              {idx + 1}. {prize}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}