import { useNavigate } from 'react-router';
import imgCaixa1 from 'figma:asset/0317f8d589845af7d6526da034f4acdba48d9443.png';
import imgCaixa2 from 'figma:asset/0317f8d589845af7d6526da034f4acdba48d9443.png';
import imgCaixa3 from 'figma:asset/0317f8d589845af7d6526da034f4acdba48d9443.png';

export default function Home() {
  const navigate = useNavigate();

  const boxes = [
    {
      id: 1,
      name: "🔥 CAIXA SURPRESA 🔥",
      price: "R$ 15",
      gradient: "from-red-500 via-orange-500 to-red-500",
      shadow: "shadow-[0_0_40px_rgba(255,69,0,0.7)]",
      hoverShadow: "hover:shadow-[0_0_60px_rgba(255,69,0,1)]",
      image: imgCaixa1
    },
    {
      id: 2,
      name: "💎 CAIXA PREMIUM 💎",
      price: "R$ 30",
      gradient: "from-cyan-500 via-blue-500 to-cyan-500",
      shadow: "shadow-[0_0_40px_rgba(0,191,255,0.7)]",
      hoverShadow: "hover:shadow-[0_0_60px_rgba(0,191,255,1)]",
      image: imgCaixa2
    },
    {
      id: 3,
      name: "👑 CAIXA LENDÁRIA 👑",
      price: "R$ 90",
      gradient: "from-yellow-500 via-amber-500 to-yellow-500",
      shadow: "shadow-[0_0_40px_rgba(255,215,0,0.7)]",
      hoverShadow: "hover:shadow-[0_0_60px_rgba(255,215,0,1)]",
      image: imgCaixa3
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white">
      {/* Header */}
      <div className="text-center py-10">
        <h1 className="text-6xl font-black mb-3 bg-gradient-to-r from-red-500 via-purple-500 to-blue-500 bg-clip-text text-transparent animate-pulse">
          🖤 KRATOS STORE 🖤
        </h1>
        <p className="text-xl text-gray-300">Escolha sua caixa e teste sua sorte! 🔥</p>
        <p className="text-sm text-gray-500 mt-2">Valores promocionais • Aproveite!</p>
      </div>

      {/* Boxes Grid */}
      <div className="container mx-auto px-4 pb-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {boxes.map((box) => (
            <div
              key={box.id}
              className={`group relative bg-gradient-to-br ${box.gradient} p-[2px] rounded-3xl ${box.shadow} ${box.hoverShadow} transition-all duration-500 hover:scale-105 cursor-pointer`}
              onClick={() => navigate(`/payment/${box.id}`)}
            >
              <div className="bg-gray-900 rounded-3xl p-6 h-full flex flex-col">
                {/* Image */}
                <div className="relative rounded-2xl overflow-hidden mb-4">
                  <img
                    src={box.image}
                    alt={box.name}
                    className="w-full h-auto group-hover:scale-110 transition-transform duration-500"
                  />
                </div>

                {/* Title & Price */}
                <h2 className="text-2xl font-bold text-center mb-2">{box.name}</h2>
                <div className={`text-4xl font-black text-center mb-4 bg-gradient-to-r ${box.gradient} bg-clip-text text-transparent`}>
                  {box.price}
                </div>

                {/* Button */}
                <button className={`mt-auto w-full py-4 rounded-xl bg-gradient-to-r ${box.gradient} font-bold text-lg hover:brightness-125 transition-all duration-300 shadow-lg`}>
                  COMPRAR AGORA
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer Info */}
      <div className="text-center pb-8 px-4">
        <p className="text-gray-400 text-sm">
          🔒 Pagamento seguro via PIX • Prêmios entregues instantaneamente
        </p>
        <p className="text-gray-500 text-xs mt-2">
          Kratos Store • Desde 2024
        </p>
      </div>
    </div>
  );
}