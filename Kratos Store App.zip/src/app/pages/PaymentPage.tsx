import { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import { QRCodeSVG } from 'qrcode.react';
import { Copy, Check, ArrowLeft, Loader2 } from 'lucide-react';

export default function PaymentPage() {
  const { boxType } = useParams();
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'waiting' | 'checking' | 'confirmed' | 'error'>('waiting');
  const [errorMessage, setErrorMessage] = useState('');

  // MODO DEMO: Usar chave PIX estática
  // Em produção, você criaria uma cobrança dinâmica via API do ProPay
  const PIX_KEY = 'cfd24f43-d0d8-4414-a10a-020c93825fe2';
  
  // TODO: Descomentar quando tiver a API Key do ProPay configurada
  // const [chargeId, setChargeId] = useState<string | null>(null);
  // const [pixCode, setPixCode] = useState<string>('');

  const boxInfo: Record<string, { name: string; price: string; priceValue: string; color: string }> = {
    '1': { name: '🔥 CAIXA SURPRESA', price: 'R$ 15', priceValue: '15.00', color: 'from-red-500 to-orange-500' },
    '2': { name: '💎 CAIXA PREMIUM', price: 'R$ 30', priceValue: '30.00', color: 'from-cyan-500 to-blue-500' },
    '3': { name: '👑 CAIXA LENDÁRIA', price: 'R$ 90', priceValue: '90.00', color: 'from-yellow-500 to-amber-500' },
  };

  const currentBox = boxInfo[boxType || '1'];

  // TODO: Descomentar para usar API real do ProPay
  // useEffect(() => {
  //   createCharge();
  // }, []);

  // const createCharge = async () => {
  //   try {
  //     setLoading(true);
  //     const charge = await createPixCharge({
  //       amount: parseFloat(currentBox.priceValue),
  //       description: `${currentBox.name} - Kratos Store`,
  //     });
  //     setChargeId(charge.id);
  //     setPixCode(charge.pixCode);
  //   } catch (error) {
  //     setErrorMessage('Erro ao gerar cobrança PIX. Tente novamente.');
  //     setPaymentStatus('error');
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(PIX_KEY);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePaymentConfirmed = async () => {
    // MODO DEMO: Libera direto (REMOVER EM PRODUÇÃO)
    // navigate(`/roulette/${boxType}`);
    
    // MODO PRODUÇÃO: Verifica o pagamento via API
    try {
      setPaymentStatus('checking');
      setLoading(true);

      // TODO: Descomentar quando configurar API do ProPay
      // if (!chargeId) {
      //   throw new Error('ID da cobrança não encontrado');
      // }

      // const status = await checkPaymentStatus(chargeId);
      
      // if (status.status === 'paid') {
      //   setPaymentStatus('confirmed');
      //   setTimeout(() => {
      //     navigate(`/roulette/${boxType}?paymentId=${chargeId}`);
      //   }, 1500);
      // } else {
      //   setErrorMessage('Pagamento ainda não confirmado. Aguarde alguns segundos após pagar.');
      //   setPaymentStatus('waiting');
      // }

      // SIMULAÇÃO (REMOVER EM PRODUÇÃO)
      setTimeout(() => {
        setPaymentStatus('confirmed');
        setTimeout(() => {
          navigate(`/roulette/${boxType}?verified=true`);
        }, 1500);
      }, 2000);

    } catch (error) {
      setErrorMessage('Erro ao verificar pagamento. Tente novamente.');
      setPaymentStatus('error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        {/* Back Button */}
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-gray-400 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Voltar</span>
        </button>

        {/* Payment Card */}
        <div className="bg-gray-900 rounded-3xl p-8 shadow-2xl border border-gray-800">
          {/* Header */}
          <div className="text-center mb-6">
            <h1 className={`text-3xl font-bold mb-2 bg-gradient-to-r ${currentBox.color} bg-clip-text text-transparent`}>
              {currentBox.name}
            </h1>
            <p className="text-5xl font-black text-white">{currentBox.price}</p>
            <p className="text-sm text-gray-400 mt-2">Pagamento via PIX</p>
          </div>

          {/* Status Messages */}
          {paymentStatus === 'checking' && (
            <div className="bg-blue-900/30 border border-blue-500 rounded-xl p-4 mb-6 flex items-center gap-3">
              <Loader2 className="animate-spin" size={24} />
              <div>
                <p className="font-bold">Verificando pagamento...</p>
                <p className="text-sm text-gray-300">Aguarde um momento</p>
              </div>
            </div>
          )}

          {paymentStatus === 'confirmed' && (
            <div className="bg-green-900/30 border border-green-500 rounded-xl p-4 mb-6">
              <p className="font-bold text-green-400">✅ Pagamento confirmado!</p>
              <p className="text-sm text-gray-300">Redirecionando para a roleta...</p>
            </div>
          )}

          {paymentStatus === 'error' && (
            <div className="bg-red-900/30 border border-red-500 rounded-xl p-4 mb-6">
              <p className="font-bold text-red-400">❌ Erro</p>
              <p className="text-sm text-gray-300">{errorMessage}</p>
            </div>
          )}

          {/* QR Code */}
          <div className="bg-white p-6 rounded-2xl mb-6 flex justify-center">
            <QRCodeSVG
              value={PIX_KEY}
              size={200}
              level="H"
              includeMargin={true}
            />
          </div>

          {/* Instructions */}
          <div className="space-y-4 mb-6">
            <div className="bg-gray-800 rounded-xl p-4">
              <h3 className="font-bold mb-2 flex items-center gap-2">
                📱 Como pagar:
              </h3>
              <ol className="text-sm text-gray-300 space-y-1 ml-4 list-decimal">
                <li>Abra o app do seu banco</li>
                <li>Escolha pagar com PIX</li>
                <li>Escaneie o QR Code ou copie a chave</li>
                <li>Confirme o pagamento de <strong>{currentBox.price}</strong></li>
                <li>Clique em "Já fiz o pagamento"</li>
              </ol>
            </div>

            {/* PIX Key */}
            <div className="bg-gray-800 rounded-xl p-4">
              <label className="text-xs text-gray-400 mb-2 block">Chave PIX (Copia e Cola):</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={PIX_KEY}
                  readOnly
                  className="flex-1 bg-gray-700 text-white px-4 py-2 rounded-lg text-sm font-mono"
                />
                <button
                  onClick={copyToClipboard}
                  className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors"
                >
                  {copied ? <Check size={20} /> : <Copy size={20} />}
                </button>
              </div>
              {copied && (
                <p className="text-green-400 text-xs mt-2">✓ Chave copiada!</p>
              )}
            </div>
          </div>

          {/* Confirm Button */}
          <button
            onClick={handlePaymentConfirmed}
            disabled={loading || paymentStatus === 'confirmed'}
            className={`w-full py-4 rounded-xl font-bold text-lg transition-all duration-300 shadow-lg flex items-center justify-center gap-2 ${
              loading || paymentStatus === 'confirmed'
                ? 'bg-gray-600 cursor-not-allowed'
                : `bg-gradient-to-r ${currentBox.color} hover:brightness-125`
            }`}
          >
            {loading ? (
              <>
                <Loader2 className="animate-spin" size={20} />
                <span>Verificando...</span>
              </>
            ) : paymentStatus === 'confirmed' ? (
              <span>✅ CONFIRMADO</span>
            ) : (
              <span>✅ JÁ FIZ O PAGAMENTO</span>
            )}
          </button>

          {/* Security Info */}
          <div className="mt-6 text-center">
            <p className="text-xs text-gray-500">
              🔒 Ambiente seguro • Seus dados estão protegidos
            </p>
            <p className="text-xs text-gray-600 mt-1">
              O pagamento será verificado automaticamente
            </p>
          </div>
        </div>

        {/* Extra Info */}
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-400">
            💬 Dúvidas? Entre em contato via WhatsApp
          </p>
          <a
            href="https://wa.me/5551995588124"
            target="_blank"
            rel="noopener noreferrer"
            className="text-green-400 hover:text-green-300 text-sm font-bold"
          >
            📱 (51) 99558-8124
          </a>
        </div>
      </div>
    </div>
  );
}