📁 Estrutura de Arquivos
1. /src/app/App.tsx
import { RouterProvider } from 'react-router';
import { router } from './routes';

export default function App() {
  return <RouterProvider router={router} />;
}
2. /src/app/routes.tsx
import { createBrowserRouter } from "react-router";
import Home from "./pages/Home";
import PaymentPage from "./pages/PaymentPage";
import RoulettePage from "./pages/RoulettePage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/payment/:boxType",
    Component: PaymentPage,
  },
  {
    path: "/roulette/:boxType",
    Component: RoulettePage,
  },
]);
3. /src/app/pages/Home.tsx
import { useNavigate } from 'react-router';
import imgCaixa1 from 'figma:asset/6203529ea6014ba9f3a98a42503ed84e24c3d81d.png';
import imgCaixa2 from 'figma:asset/fb06ca7e1e83ad04f503f150902a2b2b32b29d87.png';
import imgCaixa3 from 'figma:asset/d91c7d29ec76d6a6af5b10e4379cc0d913c34fde.png';

export default function Home() {
  const navigate = useNavigate();

  const boxes = [
    {
      id: 1,
      name: "🔥 CAIXA SURPRESA 🔥",
      price: "R$ 15",
      gradient: "from-red-500 via-orange-500 to-red-500",
      shadow: "shadow-[0_0_40px_rgba(255,69,0,0.7)]",
      hoverShadow: "hover:shadow-[0_0_60px_rgba(255,69,0,1)]",
      image: imgCaixa1
    },
    {
      id: 2,
      name: "💎 CAIXA PREMIUM 💎",
      price: "R$ 30",
      gradient: "from-cyan-500 via-blue-500 to-cyan-500",
      shadow: "shadow-[0_0_40px_rgba(0,191,255,0.7)]",
      hoverShadow: "hover:shadow-[0_0_60px_rgba(0,191,255,1)]",
      image: imgCaixa2
    },
    {
      id: 3,
      name: "👑 CAIXA LENDÁRIA 👑",
      price: "R$ 90",
      gradient: "from-yellow-500 via-amber-500 to-yellow-500",
      shadow: "shadow-[0_0_40px_rgba(255,215,0,0.7)]",
      hoverShadow: "hover:shadow-[0_0_60px_rgba(255,215,0,1)]",
      image: imgCaixa3
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white">
      {/* Header */}
      <div className="text-center py-10">
        <h1 className="text-6xl font-black mb-3 bg-gradient-to-r from-red-500 via-purple-500 to-blue-500 bg-clip-text text-transparent animate-pulse">
          🖤 KRATOS STORE 🖤
        </h1>
        <p className="text-xl text-gray-300">Escolha sua caixa e teste sua sorte! 🔥</p>
        <p className="text-sm text-gray-500 mt-2">Valores promocionais • Aproveite!</p>
      </div>

      {/* Boxes Grid */}
      <div className="container mx-auto px-4 pb-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {boxes.map((box) => (
            <div
              key={box.id}
              className={`group relative bg-gradient-to-br ${box.gradient} p-[2px] rounded-3xl ${box.shadow} ${box.hoverShadow} transition-all duration-500 hover:scale-105 cursor-pointer`}
              onClick={() => navigate(`/payment/${box.id}`)}
            >
              <div className="bg-gray-900 rounded-3xl p-6 h-full flex flex-col">
                {/* Image */}
                <div className="relative rounded-2xl overflow-hidden mb-4">
                  <img
                    src={box.image}
                    alt={box.name}
                    className="w-full h-auto group-hover:scale-110 transition-transform duration-500"
                  />
                </div>

                {/* Title & Price */}
                <h2 className="text-2xl font-bold text-center mb-2">{box.name}</h2>
                <div className={`text-4xl font-black text-center mb-4 bg-gradient-to-r ${box.gradient} bg-clip-text text-transparent`}>
                  {box.price}
                </div>

                {/* Button */}
                <button className={`mt-auto w-full py-4 rounded-xl bg-gradient-to-r ${box.gradient} font-bold text-lg hover:brightness-125 transition-all duration-300 shadow-lg`}>
                  COMPRAR AGORA
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer Info */}
      <div className="text-center pb-8 px-4">
        <p className="text-gray-400 text-sm">
          🔒 Pagamento seguro via PIX • Prêmios entregues instantaneamente
        </p>
        <p className="text-gray-500 text-xs mt-2">
          Kratos Store • Desde 2024
        </p>
      </div>
    </div>
  );
}
4. /src/app/pages/PaymentPage.tsx
import { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import { QRCodeSVG } from 'qrcode.react';
import { Copy, Check, ArrowLeft } from 'lucide-react';

export default function PaymentPage() {
  const { boxType } = useParams();
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);

  const PIX_KEY = 'cfd24f43-d0d8-4414-a10a-020c93825fe2';

  const boxInfo: Record<string, { name: string; price: string; priceValue: string; color: string }> = {
    '1': { name: '🔥 CAIXA SURPRESA', price: 'R$ 15', priceValue: '15.00', color: 'from-red-500 to-orange-500' },
    '2': { name: '💎 CAIXA PREMIUM', price: 'R$ 30', priceValue: '30.00', color: 'from-cyan-500 to-blue-500' },
    '3': { name: '👑 CAIXA LENDÁRIA', price: 'R$ 90', priceValue: '90.00', color: 'from-yellow-500 to-amber-500' },
  };

  const currentBox = boxInfo[boxType || '1'];

  const copyToClipboard = () => {
    navigator.clipboard.writeText(PIX_KEY);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePaymentConfirmed = () => {
    // Na produção, você verificaria o webhook do gateway de pagamento
    navigate(`/roulette/${boxType}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        {/* Back Button */}
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-gray-400 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Voltar</span>
        </button>

        {/* Payment Card */}
        <div className="bg-gray-900 rounded-3xl p-8 shadow-2xl border border-gray-800">
          {/* Header */}
          <div className="text-center mb-6">
            <h1 className={`text-3xl font-bold mb-2 bg-gradient-to-r ${currentBox.color} bg-clip-text text-transparent`}>
              {currentBox.name}
            </h1>
            <p className="text-5xl font-black text-white">{currentBox.price}</p>
            <p className="text-sm text-gray-400 mt-2">Pagamento via PIX</p>
          </div>

          {/* QR Code */}
          <div className="bg-white p-6 rounded-2xl mb-6 flex justify-center">
            <QRCodeSVG
              value={PIX_KEY}
              size={200}
              level="H"
              includeMargin={true}
            />
          </div>

          {/* Instructions */}
          <div className="space-y-4 mb-6">
            <div className="bg-gray-800 rounded-xl p-4">
              <h3 className="font-bold mb-2 flex items-center gap-2">
                📱 Como pagar:
              </h3>
              <ol className="text-sm text-gray-300 space-y-1 ml-4 list-decimal">
                <li>Abra o app do seu banco</li>
                <li>Escolha pagar com PIX</li>
                <li>Escaneie o QR Code ou copie a chave</li>
                <li>Confirme o pagamento de <strong>{currentBox.price}</strong></li>
                <li>Clique em "Já fiz o pagamento"</li>
              </ol>
            </div>

            {/* PIX Key */}
            <div className="bg-gray-800 rounded-xl p-4">
              <label className="text-xs text-gray-400 mb-2 block">Chave PIX (Copia e Cola):</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={PIX_KEY}
                  readOnly
                  className="flex-1 bg-gray-700 text-white px-4 py-2 rounded-lg text-sm font-mono"
                />
                <button
                  onClick={copyToClipboard}
                  className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors"
                >
                  {copied ? <Check size={20} /> : <Copy size={20} />}
                </button>
              </div>
              {copied && (
                <p className="text-green-400 text-xs mt-2">✓ Chave copiada!</p>
              )}
            </div>
          </div>

          {/* Confirm Button */}
          <button
            onClick={handlePaymentConfirmed}
            className={`w-full py-4 rounded-xl bg-gradient-to-r ${currentBox.color} font-bold text-lg hover:brightness-125 transition-all duration-300 shadow-lg`}
          >
            ✅ JÁ FIZ O PAGAMENTO
          </button>

          {/* Security Info */}
          <div className="mt-6 text-center">
            <p className="text-xs text-gray-500">
              🔒 Ambiente seguro • Seus dados estão protegidos
            </p>
            <p className="text-xs text-gray-600 mt-1">
              Após o pagamento, você será redirecionado automaticamente
            </p>
          </div>
        </div>

        {/* Extra Info */}
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-400">
            💬 Dúvidas? Entre em contato via WhatsApp
          </p>
          <a
            href="https://wa.me/5551995588124"
            target="_blank"
            rel="noopener noreferrer"
            className="text-green-400 hover:text-green-300 text-sm font-bold"
          >
            📱 (51) 99558-8124
          </a>
        </div>
      </div>
    </div>
  );
}
5. /src/app/pages/RoulettePage.tsx
import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router';
import confetti from 'canvas-confetti';
import { ArrowLeft, Sparkles } from 'lucide-react';

export default function RoulettePage() {
  const { boxType } = useParams();
  const navigate = useNavigate();
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [winner, setWinner] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);

  // Definição dos prêmios para cada caixa
  const prizes: Record<string, string[]> = {
    '1': [
      "50 dimas",
      "100 dimas",
      "sensi",
      "codiguinho",
      "50 dimas",
      "passe booyah 🔥",
      "100 dimas",
      "50 dimas",
      "sensi",
      "200 dimas (Raro)"
    ],
    '2': [
      "100 dimas", "200 dimas", "sensi premium", "100 dimas", "codiguinho",
      "100 dimas", "200 dimas", "100 dimas", "sensi premium", "310 dimas 🔵",
      "100 dimas", "200 dimas", "codiguinho", "100 dimas", "sensi premium",
      "100 dimas", "200 dimas", "100 dimas", "codiguinho", "520 dimas 🟣",
      "100 dimas", "200 dimas", "sensi premium", "100 dimas", "codiguinho",
      "100 dimas", "200 dimas", "100 dimas", "Passe Booyah 🔥", "1040 dimas 🟡"
    ],
    '3': [
      "310 dimas", "520 dimas", "sensi premium", "310 dimas", "codiguinho top",
      "310 dimas", "520 dimas", "310 dimas", "sensi premium", "1040 dimas 🔵",
      "310 dimas", "520 dimas", "codiguinho top", "310 dimas", "sensi premium",
      "310 dimas", "520 dimas", "310 dimas", "codiguinho top", "1560 dimas 🟣",
      "310 dimas", "520 dimas", "sensi premium", "310 dimas", "codiguinho top",
      "310 dimas", "520 dimas", "310 dimas", "Passe Booyah + bônus 🔥", "2120 dimas 🟡"
    ]
  };

  const currentPrizes = prizes[boxType || '1'];
  const numberOfPrizes = currentPrizes.length;

  // Cores alternadas para os segmentos
  const getSegmentColor = (index: number) => {
    // Roleta toda preta
    return 'from-black to-gray-900';
  };

  const spinRoulette = () => {
    if (spinning) return;

    setSpinning(true);
    setWinner(null);
    setShowResult(false);

    // Sorteia um prêmio
    const winnerIndex = Math.floor(Math.random() * numberOfPrizes);
    const winnerPrize = currentPrizes[winnerIndex];

    // Calcula rotação final (múltiplas voltas + posição do prêmio)
    const segmentAngle = 360 / numberOfPrizes;
    const extraSpins = 5; // Número de voltas completas
    const targetRotation = (extraSpins * 360) + (360 - (winnerIndex * segmentAngle) - (segmentAngle / 2));

    setRotation(targetRotation);

    // Após a animação
    setTimeout(() => {
      setWinner(winnerPrize);
      setSpinning(false);
      setShowResult(true);
      
      // Confetti para prêmios raros
      if (winnerPrize.includes('Raro') || winnerPrize.includes('🔵') || winnerPrize.includes('🟣') || winnerPrize.includes('🟡') || winnerPrize.includes('🔥')) {
        confetti({
          particleCount: 200,
          spread: 100,
          origin: { y: 0.6 }
        });
      }

      // Notificação (em produção seria webhook para você)
      console.log('🎉 ALGUÉM GANHOU!', {
        premio: winnerPrize,
        caixa: boxType,
        timestamp: new Date().toISOString()
      });

      // Aqui você integraria com Telegram Bot ou API para receber notificação real
      // sendTelegramNotification({ prize: winnerPrize, box: boxType });
    }, 4000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white flex flex-col items-center justify-center p-4">
      {/* Back Button */}
      <button
        onClick={() => navigate('/')}
        className="absolute top-6 left-6 flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
      >
        <ArrowLeft size={20} />
        <span>Voltar</span>
      </button>

      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-black mb-2 bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 bg-clip-text text-transparent">
          🎰 ROLETA DA SORTE
        </h1>
        <p className="text-gray-400">Gire a roleta e descubra seu prêmio!</p>
      </div>

      {/* Roulette Container */}
      <div className="relative mb-8" ref={canvasRef}>
        {/* Seta indicadora */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-4 z-20">
          <div className="w-0 h-0 border-l-[20px] border-l-transparent border-r-[20px] border-r-transparent border-t-[40px] border-t-red-500 drop-shadow-[0_0_10px_rgba(255,0,0,0.8)]" />
        </div>

        {/* Roulette Wheel */}
        <div className="relative w-[400px] h-[400px] rounded-full overflow-hidden shadow-[0_0_60px_rgba(138,43,226,0.8)]">
          <div
            className="w-full h-full relative"
            style={{
              transform: `rotate(${rotation}deg)`,
              transition: spinning ? 'transform 4s cubic-bezier(0.17, 0.67, 0.12, 0.99)' : 'none',
            }}
          >
            {currentPrizes.map((prize, index) => {
              const segmentAngle = 360 / numberOfPrizes;
              const startAngle = index * segmentAngle;

              return (
                <div
                  key={index}
                  className={`absolute w-full h-full bg-gradient-to-br ${getSegmentColor(index)} border-r border-gray-700`}
                  style={{
                    clipPath: `polygon(50% 50%, ${50 + 50 * Math.cos((startAngle - 90) * Math.PI / 180)}% ${50 + 50 * Math.sin((startAngle - 90) * Math.PI / 180)}%, ${50 + 50 * Math.cos((startAngle + segmentAngle - 90) * Math.PI / 180)}% ${50 + 50 * Math.sin((startAngle + segmentAngle - 90) * Math.PI / 180)}%)`,
                  }}
                >
                  <div
                    className="absolute inset-0 flex items-center justify-center"
                    style={{
                      transform: `rotate(${startAngle + segmentAngle / 2}deg)`,
                      transformOrigin: 'center',
                    }}
                  >
                    <span
                      className="text-4xl"
                      style={{
                        transform: 'translateY(-120px)',
                      }}
                    >
                      🎁
                    </span>
                  </div>
                </div>
              );
            })}

            {/* Center Circle */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full shadow-xl flex items-center justify-center border-4 border-white">
              <Sparkles className="text-white" size={32} />
            </div>
          </div>
        </div>
      </div>

      {/* Spin Button */}
      {!showResult && (
        <button
          onClick={spinRoulette}
          disabled={spinning}
          className={`px-12 py-4 rounded-full font-black text-xl shadow-2xl transition-all duration-300 ${
            spinning
              ? 'bg-gray-600 cursor-not-allowed'
              : 'bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 hover:scale-110 hover:shadow-[0_0_40px_rgba(147,51,234,0.8)]'
          }`}
        >
          {spinning ? '🎰 GIRANDO...' : '🎯 GIRAR ROLETA'}
        </button>
      )}

      {/* Result */}
      {showResult && winner && (
        <div className="mt-8 text-center animate-bounce">
          <div className="bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 p-[3px] rounded-3xl shadow-[0_0_50px_rgba(255,215,0,0.8)]">
            <div className="bg-gray-900 rounded-3xl p-8">
              <h2 className="text-3xl font-black mb-4">🎉 PARABÉNS!</h2>
              <p className="text-xl mb-6">Você ganhou:</p>
              <div className="text-4xl font-black bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent mb-6">
                {winner}
              </div>

              {/* WhatsApp Contact */}
              <div className="bg-gray-800 rounded-2xl p-6 mb-4">
                <p className="text-sm text-gray-300 mb-3">
                  📱 Entre em contato para resgatar seu prêmio:
                </p>
                <a
                  href="https://wa.me/5551995588124?text=Olá! Ganhei um prêmio na roleta Kratos Store!"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 rounded-xl font-bold transition-colors"
                >
                  <span>📞 WhatsApp Kratos Store</span>
                </a>
                <p className="text-xs text-gray-500 mt-2">
                  (51) 99558-8124
                </p>
              </div>

              <button
                onClick={() => navigate('/')}
                className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl font-bold hover:brightness-125 transition-all"
              >
                🏠 Voltar para a loja
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Prize List */}
      <div className="mt-12 max-w-2xl">
        <h3 className="text-center font-bold mb-4 text-gray-400">📋 Prêmios disponíveis nesta caixa:</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {currentPrizes.map((prize, idx) => (
            <div key={idx} className="bg-gray-800/50 rounded-lg px-3 py-2 text-sm text-center text-gray-300">
              {idx + 1}. {prize}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}