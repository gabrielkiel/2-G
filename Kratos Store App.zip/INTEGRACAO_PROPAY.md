# 🔥 Integração com ProPay - Kratos Store

## 📋 Status Atual

**MODO DEMO ATIVO** ✅  
O sistema está funcionando em modo de demonstração com validação simulada de pagamento.

---

## 🚀 Como Integrar a API Real do ProPay

### 1️⃣ **Obter Credenciais da ProPay**

Acesse a documentação da ProPay e obtenha:
- **API Key** (Token de autenticação)
- **Base URL**: `https://api-connectmdcpay.squareweb.app`

### 2️⃣ **Configurar a API Key**

Abra o arquivo `/src/app/services/propay.ts` e substitua:

```typescript
const API_KEY = 'SUA_API_KEY_AQUI'; // ← Cole sua API Key aqui
```

**⚠️ IMPORTANTE**: Em produção real, use variáveis de ambiente (.env) para proteger suas credenciais!

### 3️⃣ **Ativar a Integração Real**

#### No arquivo `/src/app/pages/PaymentPage.tsx`:

**Descomentar as linhas:**
- Linha 19-20: State para `chargeId` e `pixCode`
- Linha 34-48: Função `createCharge()` e `useEffect`
- Linha 68-86: Verificação real do pagamento

**Comentar/Remover:**
- Linha 88-95: SIMULAÇÃO (código de teste)

### 4️⃣ **Como Funciona o Fluxo Real**

```
┌─────────────────┐
│  Cliente clica  │
│   na caixa      │
└────────┬────────┘
         │
         v
┌─────────────────────────────────┐
│ PaymentPage carrega             │
│ → createPixCharge() na API      │
│ → Recebe: QR Code único         │
│ → Recebe: charge ID             │
└────────┬────────────────────────┘
         │
         v
┌─────────────────────────────────┐
│ Cliente paga o PIX              │
│ → ProPay detecta pagamento      │
└────────┬────────────────────────┘
         │
         v
┌─────────────────────────────────┐
│ Cliente clica "Já paguei"       │
│ → checkPaymentStatus(chargeId)  │
│ → Se status = 'paid'            │
│   → Libera roleta! ✅           │
└─────────────────────────────────┘
```

---

## 🔒 Segurança Implementada

### ✅ **Proteção da Roleta**

A página da roleta verifica se o pagamento foi confirmado através de parâmetros na URL:

```typescript
// RoulettePage.tsx linha 18-26
const isVerified = searchParams.get('verified') === 'true';
const paymentId = searchParams.get('paymentId');

if (!isVerified && !paymentId) {
  // BLOQUEIA acesso e redireciona para pagamento
  navigate(`/payment/${boxType}`);
}
```

**Acesso permitido apenas com:**
- `?verified=true` (modo demo)
- `?paymentId=xxx` (modo produção - ID da cobrança paga)

### 🚨 **Importante**

Esta validação frontend é básica. Para produção real, você deve:

1. **Criar um backend** (Node.js, Python, etc.)
2. **Webhook da ProPay** → Seu servidor
3. **Salvar pagamentos confirmados** em banco de dados
4. **Validar no backend** antes de liberar a roleta

---

## 📱 Webhooks (Recomendado para Produção)

### Como configurar:

1. Configure um endpoint no seu servidor:
   ```
   POST https://seu-servidor.com/webhooks/propay
   ```

2. Na ProPay, registre o webhook para receber notificações automáticas quando um pagamento for confirmado

3. Quando receber webhook:
   ```javascript
   // Exemplo de webhook handler
   app.post('/webhooks/propay', async (req, res) => {
     const { chargeId, status } = req.body;
     
     if (status === 'paid') {
       // Salvar no banco que foi pago
       await db.payments.update({ chargeId, paid: true });
       
       // Enviar notificação pro WhatsApp/Telegram
       await sendNotification(`Pagamento confirmado: ${chargeId}`);
     }
     
     res.send('OK');
   });
   ```

---

## 🎯 Notificações para Você

### Console Log (Atual)

Toda vez que alguém ganha, aparece no console do navegador:

```javascript
console.log('🎉 ALGUÉM GANHOU!', {
  premio: "520 dimas 🟣",
  caixa: "2",
  timestamp: "2026-03-24T..."
});
```

### Telegram Bot (Recomendado)

Crie um bot no Telegram para receber notificações em tempo real:

```javascript
async function sendTelegramNotification(data) {
  await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: 'SEU_CHAT_ID',
      text: `🎉 NOVO GANHADOR!\n\n` +
            `💰 Prêmio: ${data.premio}\n` +
            `📦 Caixa: ${data.caixa}\n` +
            `🕐 Hora: ${new Date().toLocaleString()}`
    })
  });
}
```

---

## 📊 Checklist de Ativação

- [ ] Obter API Key da ProPay
- [ ] Configurar API Key em `propay.ts`
- [ ] Descomentar código de integração em `PaymentPage.tsx`
- [ ] Remover código de simulação
- [ ] Testar pagamento real
- [ ] Configurar webhook (opcional, mas recomendado)
- [ ] Configurar notificações (Telegram/WhatsApp)
- [ ] Criar backend para validação segura
- [ ] Salvar transações em banco de dados

---

## ❓ Suporte

**Documentação ProPay**: https://api-connectmdcpay.squareweb.app/docs  
**WhatsApp Kratos Store**: (51) 99558-8124

---

## 🎉 Pronto!

Quando configurar tudo, seu sistema estará 100% automático:

1. Cliente escolhe caixa
2. Sistema gera PIX único via ProPay
3. Cliente paga
4. ProPay notifica via webhook
5. Sistema libera roleta automaticamente
6. Você recebe notificação no Telegram
7. Cliente ganha prêmio
8. Cliente entra em contato no WhatsApp para resgatar

**Tudo funcionando sem você precisar fazer nada manualmente! 🚀**
