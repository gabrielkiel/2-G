
  # Kratos Store App

  This is a code bundle for Kratos Store App. The original project is available at https://www.figma.com/design/6eyvscpCN0aUvyeyqjqOBc/Kratos-Store-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  